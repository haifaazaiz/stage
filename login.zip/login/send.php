<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="styleadministration.css">
	<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="../css/animate.css-main/source/animate.css">
    <!-- my css-->
    <link rel="stylesheet" href="./styleadministration.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <title>Administration</title>
    <?php 
        session_start();
        $host="localhost";
        $user="root";
        $password="";
        $db="db";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        $sql=$db->prepare("SELECT * FROM msg WHERE id=?");
        $sql->execute(array($_GET['id']));
        $msg=$sql->fetch();
        $mail=$msg['email'];
        if((!empty($_POST['text']))&&(isset($_POST['submit']))){
            $header='From : haifaazaiz1@gmail.com';
            $object="the response to your request";
            $text=$_POST['text'];
            if(mail($mail,$object,$text,$header)){
                $message="Email has been successfully sent !";
                $req=$db->prepare("UPDATE messages SET reply=1 WHERE id=?");
                $req->execute(array($_GET['id']));
            }
            else{
                $message="Failed to send email!";
            }
        }
        
    ?>
</head>
<body>
    <div class="jumbotron">
    <div style="margin-left:30px;margin-top:-20px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-30px;">
            
            <a href="../index.html"  style="color:black;"><i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong></a>
        </div>
    </div>
    <div class="container">
            <div class="col-12" style="margin-top:50px;margin-left:50px;">
                <a href="adminmessage.php"  style="color:white;">Messages Management &nbsp; /</a>
             <a href="#"  style="color:grey;">Send Email</a>
    </div>
    </div>
    <div class="container">
        <CENTER>
            <form action="send.php?id=<?= $msg['id']?>" method="POST">
                <input type="textarea" id="text" name="text" placeholder="Enter your email text here" required>
                <br>
                <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm ml-1" value="Send the email">
                <br>
                <?php
                    if (isset($message)) echo $message;
                ?>
            </form>
        </CENTER>               
    </div>         
</body>
</html>