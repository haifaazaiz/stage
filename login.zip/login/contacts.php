<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/layout.css" type="text/css" media="screen">
<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script>
<!--[if lt IE 7]>
	<div style=' clear: both; text-align:center; position: relative;'>
		<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0"  alt="" /></a>
	</div>
<![endif]-->
<!--[if lt IE 9]>
	<script type="text/javascript" src="js/html5.js"></script>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<![endif]-->
</head>
<body id="page5">
<?php
		session_start();
		$host="localhost";
		$user="root";
		$password="";
		$db="db";
		try{
			// connexion à la base de données db
			$db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
			// En cas d'erreur, on affiche un message et on quitte la page
			die('Erreur : '.$e->getMessage());
		}
		if (isset($_SESSION['id'])){
			$req=$db->prepare("SELECT * FROM user WHERE id=?");
			$req->execute(array($_SESSION['id']));
			$user=$req->fetch();
		}
		if((isset($_SESSION['id']))&&!empty($_POST['nom'])&&(!empty($_POST['email']))&&(!empty($_POST['contenu'])))
        {
            $idvoyageur=$_SESSION['id'];
            $email=$_POST['email'];
            $nom=$_POST['nom'];
			$contenu=$_POST['contenu'];

            $sql="INSERT INTO msg(nom,email,contenu) VALUES (:nom, :email, :contenu)";      
            $req=$db->prepare($sql);
            $req->execute(array( 'nom' => $idvoyageur,'email' => $email,'contenu' => $contenu));
        } 
    ?>
<!-- header -->
	<div class="bg">
		<div class="main">
			<header>
				<div class="row-1">
					<div class="col-1">
						<h1>
							<a class="logo" href="home.php">Point.co</a>
							<strong class="slog">The most creative ideas</strong>
						</h1>
						<!--<form id="search-form" method="post" enctype="multipart/form-data">
							<fieldset>
								<div class="search-form">					
									<input type="text" name="search" value="Type Keyword Here" onBlur="if(this.value=='') this.value='Type Keyword Here'" onFocus="if(this.value =='Type Keyword Here' ) this.value=''" />
									<a href="#" onClick="document.getElementById('search-form').submit()">Search</a>									
								</div>
							</fieldset>
						</form>-->
					</div>
					<a class="btn" id="loginButton" role="button" style="float: right;" href="./login/Login_v1/index.html">
						<span class="fa fa-sign-in"></span>
                        <?php echo $_SESSION['fullname']; ?>
					</a>
				</div>
				
				<div class="row-2">
					<nav>
						<ul class="menu">
                            <li><a href="home.php">Accueil</a></li>
						  <li><a href="about.php">A propos</a></li>
						  <li><a href="transport.php" >Transport de colis</a></li>
						  <li><a href="colis.php" >Envoi de colis</a></li>
						  <li class="last-item"><a href="contacts.php" class="active" >Centre d&apos;aide</a></li>
						</ul>
					</nav>
				</div>
			</header>
			<!-- content -->
			<section id="content">
				<div class="padding">
					<div class="wrapper margin-bot">
						<div class="col-3">
							<div class="indent">
								<h2 class="p0">Aide pour vos reclamations</h2>
								<form id="contact-form" action="contacts.php" method="post" enctype="multipart/form-data">					
									<fieldset>
										<label><span class="text-form">Nom:</span><input name="nom" id="nom" type="text" /></label>
										<label><span class="text-form">Email:</span><input name="email" id="email" type="text" /></label>   
										<div class="wrapper"><div class="text-form">Message:</div><input name="contenu" id="contenu" type="textarea" style="height:20rem;"/></div>
										<div class="buttons">
											<a class="button-2" href="#" onClick="document.getElementById('contact-form').reset()">Annuler</a>
											<a class="button-2" href="#" onClick="document.getElementById('contact-form').submit()">Envoyer</a>
										</div>									 
									</fieldset>						
								</form>
							</div>
							
						</div>
						<div class="col-4">
							<div class="block-news">
								<h3 class="color-4 indent-bot2">Contacts</h3>
								<dl class="contact p3">
									<dt><span>Site web:</span><a href="#">www.jwebi.com</a></dt>
									<dd><span>Telephone:</span>+354 563-56-00</dd>
									<dd><span>E-mail:</span><a href="#">hello@jwebi.com</a></dd>
								</dl>
								<h3 class="color-4 indent-bot2">SUIVRE</h3>
								<p class="text-1">Après avoir envoyé votre réclamation, vous allez recevoir une notification et d’autres informations pertinentes concernant votre réclamation via votre adresse mail.</p>
							</div>
						</div>
					</div>
					<div class="box-bg">
						<div class="wrapper">
							<div class="col-1">
								<div class="box first">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">01</strong>
											<div class="extra-wrap">
												<h3 class="color-1"><strong>Comment</strong>expedier</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="colis.php">>></a>
											<div class="extra-wrap">
												Vous avez déjà cherché un moyen d'envoyer des colis?<a class="link" target="_blank" href="colis.php">Cliquez ici</a>.
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-1">
								<div class="box second">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">02</strong>
											<div class="extra-wrap">
												<h3 class="color-2"><strong>Comment</strong>transporter</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="colis.php"></a>
											<div class="extra-wrap">
												Vous voyagez souvent? Vous voulez rembourser vos frais de voyage?<a class="link" href="colis.php" target="_blank" rel="nofollow"></a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-2">
								<div class="box third">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">03</strong>
											<div class="extra-wrap">
												<h3 class="color-3"><strong>A propos</strong>de nous</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="contacts.php">>></a>
											<div class="extra-wrap">
												Découvrir notre concept, notre histoire, notre equipe.
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- footer -->
			<footer>
				<div class="row-top">
					<div class="row-padding">
						<div class="wrapper">
							<div class="col-1">
								<h4>Adresse:</h4>
								<dl class="address">
									<dt><span>Pays:</span>Tunisie</dt>
									<dd><span>Site web:</span>www.jwebi.com</dd>
									<dd><span>Telephone:</span>+354 563-56-00</dd>
									<dd><span>Email:</span><a href="#">hello@jwebi.com</a></dd>
								</dl>
							</div>
							<div class="col-2">
								<h4>Suivez-nous:</h4>
								<ul class="list-services">
									<li class="item-1"><a href="#">Facebook</a></li>
									<li class="item-2"><a href="#">Twitter</a></li>
									<li class="item-3"><a href="#">LinkedIn</a></li>
								</ul>
							</div>
							<div class="col-3">
								<h4>Pourquoi nous:</h4>
								<ul class="list-1">
									<li><a href="home.php">Accueil</a></li>
									<li><a href="about.php">A propos</a></li>
									<li><a href="colis.php">Expedier</a></li> 
									<li><a href="transport.php">Transporter</a></li>
								</ul>
							</div>
							<div class="col-4">
								<div class="indent3">
									<strong class="footer-logo">Jwebi.<strong>com</strong></strong>
								</div>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
