<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="styleadministration.css">

<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
        <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script>
<title>Administration</title>
    <?php 
        $host="localhost";
        $user="root";
        $password="";
        $db="db";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        if ((isset($_GET['remove']))&&(!empty($_GET['remove']))){
            $remove =(int)$_GET['remove'];
            $req=$db->prepare("DELETE FROM msg WHERE id=?");
            $req->execute(array($remove));
        }
        $messages=$db->query('SELECT * FROM msg ORDER BY id DESC');
    ?>
</head>
<body id="page5">
	<div class="bg">
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-20px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-30px;">
            
            <a href="../index.html"  style="color:black;"><i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong></a>
        </div>
    </div>
    <div class="container">
            <ul class="col-12 breadcrumb" style="margin-left:450px;">
                <li><a href="./admin.php">Gestion des clients</a></li>
                <li><a href="./adminvoyageur.php">Gestion des voyageurs</a></li>
                <li><a href="./admindemande.php">Gestion des demandes</a></li>
                <li><a href="./adminmessage.php">Gestion des messages</a></li>
                <li><a href="./admincommentaire.php">Gestion des commentaires</a></li>
			</ul>
    </div>
    <br>
    <div class="container">
        <table>
            <tr>
                <th style="color:white;">
                    Id
                </th>
                <th style="color:white;">
                    Nom
                </th>
                <th style="color:white;">
                    Email
                </th>
                <th style="color:white;">
                    Message
                </th>
                <th style="color:white;">
                    Répondre
                </th>
                <th style="color:white;">
                    Supprimer
                </th>
            </tr>
            <?php while($msg=$messages->fetch()){ ?>
                    <tr>
                        <td style="color:white;"><?php echo $msg['id']; $_SESSION['id']=$msg['id'];?></td>
                        <td style="color:white;"><?php echo $msg['nom']?></td>
                        <td style="color:white;"><?php echo $msg['email']; $_SESSION['email']=$msg['email'];?></td>
                        <td style="word-wrap: break-word;  width:20rem; color:white;"><?php echo $msg['contenu']; $_SESSION['contenu']=$msg['contenu'];?></td>
                        <td style="color:white;">
                            <?php if($msg['reply']==0) {?>
                            <a href="send.php?id=<?= $msg['id']?>">Reply</a>
                            <?php } ?>
                        </td>
                        <td style="color:white;">
                            <?php if($msg['remove']==0) {?>
                            <a href="adminmessage.php?remove=<?= $msg['id']?>">Remove</a>
                            <?php } ?>
                        </td>
                    </tr>
            <?php }?> 
        </table>
    </div>
    </div>
</body>