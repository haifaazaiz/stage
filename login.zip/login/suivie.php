<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/layout.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/styleColis.css">
<link rel="stylesheet" href="stylesuivie.css">
<link rel="stylesheet" href="../css/paiement.css" type="text/css" media="screen">
<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script> 
</head>
<body id="page5">
<?php
		session_start();
		$host="localhost";
		$user="root";
		$password="";
		$db="db";
		try{
			// connexion à la base de données db
			$db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
			// En cas d'erreur, on affiche un message et on quitte la page
			die('Erreur : '.$e->getMessage());
		}
		if (isset($_SESSION['id'])){
			$req=$db->prepare("SELECT * FROM user WHERE id=?");
			$req->execute(array($_SESSION['id']));
			$user=$req->fetch();
            $demandes=$db->prepare("SELECT * FROM colis WHERE idexpd=? ");
            $demandes->execute(array($_SESSION['id']));
		}
        if ((isset($_GET['remove']))&&(!empty($_GET['remove']))){
            $remove =(int)$_GET['remove'];
            $req=$db->prepare("DELETE FROM colis WHERE idC=?");
            $req->execute(array($remove));
        }
    ?>
<!-- header -->
	<div class="bg">
		<div class="main">
			<header>
				<div class="row-1">
					<div class="col-1">
						<h1>
							<a class="logo" href="home.php">Point.co</a>
							<strong class="slog">The most creative ideas</strong>
						</h1>
						<!--<form id="search-form" method="post" enctype="multipart/form-data">
							<fieldset>
								<div class="search-form">					
									<input type="text" name="search" value="Type Keyword Here" onBlur="if(this.value=='') this.value='Type Keyword Here'" onFocus="if(this.value =='Type Keyword Here' ) this.value=''" />
									<a href="#" onClick="document.getElementById('search-form').submit()">Search</a>									
								</div>
							</fieldset>
						</form>-->
					</div>
					<a class="btn" id="loginButton" role="button" style="float: right;" href="./login/Login_v1/index.html">
						<span class="fa fa-sign-in"></span>
                        <?php echo $_SESSION['fullname']; ?>
					</a>
				</div>
				<div class="row-2">
					<nav>
						<ul class="menu">
                            <li><a href="home.php">Accueil</a></li>
                            <li><a href="about.php">A propos</a></li>
                            <li><a href="transport.php">Transport de colis</a></li>
                            <li><a href="colis.php" class="active" >Envoi de colis</a></li>
                            <li class="last-item"><a href="contacts.php">Centre d&apos;aide</a></li>
						</ul>
					</nav>
				</div>
			</header>
        <!-- content -->
        <section id="content">
            <div class="padding">
                <div class="wrapper margin-bot">
                    <div class="col-4">
                        <div class="block-news">
                            <h3 class="color-4 p2">Etapes</h3>
                            <ul class="list-2">
                                <li><a href="colis.php"><NOBR>Expédier au départ de</NOBR></a></li>
                                <li><a href="colis1.php">Expédier vers</a></li>
                                <li><a href="colis2.php"><NOBR>Informations sur le colis</NOBR></a></li>
                                <li><a href="paiement.php">Paiement</a></li>
                                <li><a href="suivie.php">Suivre mes demandes</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="indent">
                        <table>
            <tr>
                <th>
                    Id
                </th>
                <th>
                    L'état de la demande
                </th>
                
                <th>
                    Paiement la demande
                </th>
                <th>
                    Visualiser la demande
                </th>
                <th>
                    Supprimer la demande
                </th>
            </tr>
            <?php while($demande=$demandes->fetch()){ ?>
                    <tr>
                        <td style="border: 1px solid black;"><?php echo $demande['idC'];?></td>
                        <td style="border: 1px solid black;"><?php echo $demande['etat'];?></td>
                        <td style="border: 1px solid black;"><?php echo $demande['paye'];?></td>
                        <td style="border: 1px solid black;"><a href="visualiser.php">Cliquer ici</a></td>
                        <td style="border: 1px solid black;">
                            <?php if($demande['remove']==0) {?>
                            <a href="suivie.php?remove=<?= $demande['idC']?>">Supprimer</a>
                            <?php } ?>
                        </td> 
                    </tr>
            <?php }?> 
        </table>
                          
                        </div>
                    </div>
                </div>
                <div class="box-bg">
                    <div class="wrapper">
                        <div class="col-1">
                            <div class="box first">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">01</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-1"><strong>Comment</strong>expedier</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php">>></a>
                                        <div class="extra-wrap">
                                            Vous avez déjà cherché un moyen d'envoyer des colis?<a class="link" target="_blank" href="colis.php">Cliquez ici</a>.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1">
                            <div class="box second">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">02</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-2"><strong>Comment</strong>transporter</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php"></a>
                                        <div class="extra-wrap">
                                            Vous voyagez souvent? Vous voulez rembourser vos frais de voyage?<a class="link" href="colis.php" target="_blank" rel="nofollow"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="box third">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">03</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-3"><strong>A propos</strong>de nous</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="contacts.php">>></a>
                                        <div class="extra-wrap">
                                            Découvrir notre concept, notre histoire, notre equipe.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <div class="row-top">
                <div class="row-padding">
                    <div class="wrapper">
                        <div class="col-1">
                            <h4>Adresse:</h4>
                            <dl class="address">
                                <dt><span>Pays:</span>Tunisie</dt>
                                <dd><span>Site web:</span>www.jwebi.com</dd>
                                <dd><span>Telephone:</span>+354 563-56-00</dd>
                                <dd><span>Email:</span><a href="#">hello@jwebi.com</a></dd>
                            </dl>
                        </div>
                        <div class="col-2">
                            <h4>Suivez-nous:</h4>
                            <ul class="list-services">
                                <li class="item-1"><a href="#">Facebook</a></li>
                                <li class="item-2"><a href="#">Twitter</a></li>
                                <li class="item-3"><a href="#">LinkedIn</a></li>
                            </ul>
                        </div>
                        <div class="col-3">
                            <h4>Pourquoi nous:</h4>
                            <ul class="list-1">
                                <li><a href="home.php">Accueil</a></li>
                                <li><a href="about.php">A propos</a></li>
                                <li><a href="colis.php">Expedier</a></li> 
                                <li><a href="transport.php">Transporter</a></li>
                            </ul>
                        </div>
                        <div class="col-4">
                            <div class="indent3">
                                <strong class="footer-logo">Jwebi.<strong>com</strong></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </div></div>