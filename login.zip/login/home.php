<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/layout.css" type="text/css" media="screen">
<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script>
<!--[if lt IE 7]>
	<div style=' clear: both; text-align:center; position: relative;'>
		<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0"  alt="" /></a>
	</div>
<![endif]-->
<!--[if lt IE 9]>
	<script type="text/javascript" src="js/html5.js"></script>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<![endif]-->
</head>
<body id="page1">
	<?php
		session_start();
		$host="localhost";
		$user="root";
		$password="";
		$db="db";
		try{
			// connexion à la base de données db
			$db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
			// En cas d'erreur, on affiche un message et on quitte la page
			die('Erreur : '.$e->getMessage());
		}
		if (isset($_SESSION['id'])){
			$req=$db->prepare("SELECT * FROM user WHERE id=?");
			$req->execute(array($_SESSION['id']));
			$user=$req->fetch();
		}
		$reponse=$db->query('SELECT * FROM trajet');
		$i=0;
		while(($entree=$reponse->fetch())&&($i<2) )
	  	{
			if($i==0){
				$trajet1=$entree;
				$i++;
			}
            else{
				$trajet2=$entree;
				$i++;
			}
		}
	?>
<!-- header -->
	<div class="bg">
		<div class="main">
			<header>
				<div class="row-1">
					<div class="col-1">
						<h1>
							<a class="logo" href="home.php">Point.co</a>
							<strong class="slog">The most creative ideas</strong>
						</h1>
						<!--<form id="search-form" method="post" enctype="multipart/form-data">
							<fieldset>
								<div class="search-form">					
									<input type="text" name="search" value="Type Keyword Here" onBlur="if(this.value=='') this.value='Type Keyword Here'" onFocus="if(this.value =='Type Keyword Here' ) this.value=''" />
									<a href="#" onClick="document.getElementById('search-form').submit()">Search</a>									
								</div>
							</fieldset>
						</form>-->
					</div>
					
					
						<p  style="float: right;">
						<?php echo $_SESSION['fullname']; ?>
						<br>
						<?php if($_SESSION['type']==1) { ?>
						<a href="admin.php">Accéder à l'administration</a>
						<?php } ?>
						<br>
						<a href="logout.php">Log out</a>
						</p>
				</div>
				<div class="row-2">
					<nav>
						<ul class="menu">
						  <li><a class="active" href="home.php">Accueil</a></li>
						  <li><a href="about.php">A propos</a></li>
						  <li><a href="transport.php">Transport de colis</a></li>
						  <li><a href="colis.php">Envoi de colis</a></li>
						  <li class="last-item"><a href="contacts.php">Centre d&apos;aide</a></li>
						</ul>
					</nav>
				</div>
				<div class="row-3">
					<div class="slider-wrapper">
						<div class="slider">
						  <ul class="items">
							<li>
								<strong class="banner">
									<strong class="b2">Envoyez</strong>
									<strong class="b1">tout type de colis</strong>
								</strong>
								<img src="../images/slider-img1.jpg" alt="" >
							</li>
							<li>
								<strong class="banner">
									<strong class="b2">Amortissez</strong>
									<strong class="b1">votre billet d'avion</strong>
								</strong>
								<img src="../images/slider-img2.jpg" alt="">
							</li>
							<li><img src="../images/slider-img3.jpg" alt="">
								<strong class="banner">
									<strong class="b2">Profitez</strong>
									<strong class="b1">de nos services</strong>
								</strong>
							</li>
						  </ul>
						  <a class="prev" href="#">prev</a>
						  <a class="next" href="#">prev</a>
						</div>
					</div>
				</div>
			</header>
<!-- content -->
			<section id="content">
				<div class="padding">
					<div class="box-bg">
						<div class="wrapper">
							<div class="col-1">
								<div class="box first">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">01</strong>
											<div class="extra-wrap">
												<h3 class="color-1"><strong>Comment</strong>expedier</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="colis.php">>></a>
											<div class="extra-wrap">
												Vous avez déjà cherché un moyen d'envoyer des colis?<a class="link" target="_blank" href="colis.php">Cliquez ici</a>.
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-1">
								<div class="box second">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">02</strong>
											<div class="extra-wrap">
												<h3 class="color-2"><strong>Comment</strong>transporter</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="colis.php"></a>
											<div class="extra-wrap">
												Vous voyagez souvent? Vous voulez rembourser vos frais de voyage?<a class="link" href="colis.php" target="_blank" rel="nofollow"></a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-2">
								<div class="box third">
									<div class="pad">
										<div class="wrapper indent-bot">
											<strong class="numb img-indent2">03</strong>
											<div class="extra-wrap">
												<h3 class="color-3"><strong>A propos</strong>de nous</h3>
											</div>
										</div>
										<div class="wrapper">
											<a class="button img-indent-r" href="contacts.php">>></a>
											<div class="extra-wrap">
												Découvrir notre concept, notre histoire, notre equipe.
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="wrapper">
						<div class="col-3">
							<div class="indent">
								<h2>
									Notre Mission</h2>
								<p class="color-4 p1">
									Envoyer un colis à l'international n'a jamais été aussi 
									rapisde, simple et économique.Fini les dépenses onéreuses
									pour effectuer un envoi express.Renseigner destination ainsi 
									que la date d'envoi souhaitée. Trouvez un voyageur pour le méme
									trajet qui vous transportera votre colis à bon marché.
								</p>
								<div class="wrapper">
									<figure class="img-indent3"><img src="../images/page1-img1.png" alt="" /></figure>
									<div class="extra-wrap">
										<div class="indent2">
											Vous voyagez et vos valises ne sont pas toutes remplies? 
											Pourquoi ne pas rentabiliser les kilogrammes non utilisés 
											en proposant un service de covalisage ?
											Faites une annonce, fixez votre prix au kilogramme et 
											amortissez le prix d'achat de votre billet d'avion.
										</div>
									</div>
								</div>
								<a class="button-2" href="about.php">
									Lire la suite</a>
							</div>
						</div>
						<div class="col-2">
							<div class="block-news">
								<h3 class="color-4 p2">Annonces</h3>
								<div class="wrapper p2">
									<time class="tdate-1 fleft" datetime="2011-05-29"><strong>29</strong>mai</time>
									<div class="extra-wrap">
										<h5><?php echo $trajet1['villedep']; ?></h5> 
										sodales proin fermen<br>tum condimentum eros quis tincidunt fraesent eleifend tempor nisi, in adipiscing... <a href="#">more</a>
									</div>
								</div>
								<div class="wrapper">
									<time class="tdate-1 fleft" datetime="2011-05-24"><strong>24</strong>mai</time>
									<div class="extra-wrap">
										<h5>Felis molestie vitae</h5> 
										Sed massa justo pellen<br>tesque turpis lorem, ornare sit amet vulpate at, consectetur vitae nunc... <a href="#">more</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
<!-- footer -->
<footer>
	<div class="row-top">
		<div class="row-padding">
			<div class="wrapper">
				<div class="col-1">
					<h4>Adresse:</h4>
					<dl class="address">
						<dt><span>Pays:</span>Tunisie</dt>
						<dd><span>Site web:</span>www.jwebi.com</dd>
						<dd><span>Telephone:</span>+354 563-56-00</dd>
						<dd><span>Email:</span><a href="#">hello@jwebi.com</a></dd>
					</dl>
				</div>
				<div class="col-2">
					<h4>Suivez-nous:</h4>
					<ul class="list-services">
						<li class="item-1"><a href="#">Facebook</a></li>
						<li class="item-2"><a href="#">Twitter</a></li>
						<li class="item-3"><a href="#">LinkedIn</a></li>
					</ul>
				</div>
				<div class="col-3">
					<h4>Pourquoi nous:</h4>
					<ul class="list-1">
						<li><a href="home.php">Accueil</a></li>
						<li><a href="about.php">A propos</a></li>
						<li><a href="colis.php">Expedier</a></li> 
						<li><a href="transport.php">Transporter</a></li>
					</ul>
				</div>
				<div class="col-4">
					<div class="indent3">
						<strong class="footer-logo">Jwebi.<strong>com</strong></strong>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
		</div>
	</div>
	<script type="text/javascript"> Cufon.now(); </script>
	<script type="text/javascript">
		$(function(){
			$('.slider')._TMS({
				prevBu:'.prev',
				nextBu:'.next',
				playBu:'.play',
				duration:800,
				easing:'easeOutQuad',
				preset:'simpleFade',
				pagination:false,
				slideshow:3000,
				numStatus:false,
				pauseOnHover:true,
				banners:true,
				waitBannerAnimation:false,
				bannerShow:function(banner){
					banner
						.hide()
						.fadeIn(500)
				},
				bannerHide:function(banner){
					banner
						.show()
						.fadeOut(500)
				}
			});
		})
	</script>
</body>
</html>
