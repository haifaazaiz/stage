<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/layout.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/styleColis.css">
<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script> 
</head>
<body id="page5">
<?php
		session_start();
		$host="localhost";
		$user="root";
		$password="";
		$db="db";
		try{
			// connexion à la base de données db
			$db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
			// En cas d'erreur, on affiche un message et on quitte la page
			die('Erreur : '.$e->getMessage());
		}
		if (isset($_SESSION['id'])){
			$req=$db->prepare("SELECT * FROM user WHERE id=?");
			$req->execute(array($_SESSION['id']));
			$user=$req->fetch();
		}
        
        if((isset($_SESSION['id']))&&!empty($_POST['adrdest'])&&(!empty($_POST['villedest']))&&!empty($_POST['codedest'])&&!empty($_POST['phonedest'])
        &&!empty($_POST['emaildest']) &&!empty($_POST['nomdest']))
        {
            $randomid=$_SESSION['idrandom'];
            $idexpd=$_SESSION['id'];
            $adrdest=$_POST['adrdest'];
            $villedest=$_POST['villedest'];
            $codedest=$_POST['codedest'];
            $nomdest=$_POST['nomdest'];
            $emaildest=$_POST['emaildest'];
            $phonedest=$_POST['phonedest'];

            $sql="UPDATE colis SET paysliv='tunisie' WHERE idexpd=$idexpd AND randomid=$randomid";      
            if($db->query($sql) === true){
                echo "Records were updated successfully.";
            } 
            $sql1=$db->prepare("UPDATE colis SET adresselivraison=? WHERE idexpd=? AND randomid=?");
            $sql1->execute(array( $adrdest,$idexpd,$randomid)); 
           
            $sql2=$db->prepare("UPDATE colis SET codepostalliv=? WHERE idexpd=? AND randomid=?");      
            $sql2->execute(array( $codedest,$idexpd,$randomid)); 

            $sql3=$db->prepare("UPDATE colis SET villeliv=? WHERE idexpd= ? AND randomid= ?");      
            $sql3->execute(array($villedest,$idexpd,$randomid)); 
            
            $sql4=$db->prepare("UPDATE colis SET emaildestinataire=?  WHERE idexpd= ? AND randomid= ?");      
            $sql4->execute(array( $emaildest,$idexpd,$randomid)); 

            $sql5=$db->prepare("UPDATE colis SET teldestinataire= ?  WHERE idexpd= ? AND randomid= ?");      
            $sql5->execute(array( $phonedest,$idexpd,$randomid)); 

            $sql6=$db->prepare("UPDATE colis SET nomdestinataire= ? WHERE idexpd= ? AND randomid= ?");      
            $sql6->execute(array( $nomdest,$idexpd,$randomid)); 


            echo " Your pub was successful !" ;   
            header("Location:colis2.php");
        }
    ?>
<!-- header -->
	<div class="bg">
		<div class="main">
			<header>
				<div class="row-1">
					<div class="col-1">
						<h1>
							<a class="logo" href="index.html">Point.co</a>
							<strong class="slog">The most creative ideas</strong>
						</h1>
						<!--<form id="search-form" method="post" enctype="multipart/form-data">
							<fieldset>
								<div class="search-form">					
									<input type="text" name="search" value="Type Keyword Here" onBlur="if(this.value=='') this.value='Type Keyword Here'" onFocus="if(this.value =='Type Keyword Here' ) this.value=''" />
									<a href="#" onClick="document.getElementById('search-form').submit()">Search</a>									
								</div>
							</fieldset>
						</form>-->
					</div>
					<a class="btn" id="loginButton" role="button" style="float: right;" href="./login/Login_v1/index.html">
						<span class="fa fa-sign-in"></span>
                        <?php echo $_SESSION['fullname']; ?>
					</a>
				</div>
				<div class="row-2">
					<nav>
						<ul class="menu">
                            <li><a href="home.php">Accueil</a></li>
                            <li><a href="about.php">A propos</a></li>
                            <li><a href="transport.php">Transport de colis</a></li>
                            <li><a href="colis.php" class="active" >Envoi de colis</a></li>
                            <li class="last-item"><a href="contacts.php">Centre d&apos;aide</a></li>
						</ul>
					</nav>
				</div>
			</header>
        <!-- content -->
        <section id="content">
            <div class="padding">
                <div class="wrapper margin-bot">
                    <div class="col-4">
                       
                            <!--<h3 class="color-4 indent-bot2">Contacts</h3>
                            <dl class="contact p3">
                                <dt><span>Our Address:</span>USA, San Diego</dt>
                                <dd><span>Telephone:</span>+354 563-56-00</dd>
                                <dd><span>E-mail:</span><a href="#">point.co@mail.com</a></dd>
                            </dl>
                            <h3 class="color-4 indent-bot2">Miscellaneous</h3>
                            <p class="text-1">Lorem ipsum dolor sit amet, consectetur adipi<br>scing elit. Mauris quis consectetur nulla. Suspendisse tellus enim, molestie congue male<br>suada sed.</p>-->
                        <div class="block-news">
                            <h3 class="color-4 p2">Etapes</h3>
                            <ul class="list-2">
                                <li><a href="colis.php"><NOBR>Expédier au départ de</NOBR></a></li>
                                <li><a href="colis1.php">Expédier vers</a></li>
                                <li><a href="colis2.php"><NOBR>Informations sur le colis</NOBR></a></li>
                                <li><a href="paiement.php">Paiement</a></li>
                                <li><a href="suivie.php">Suivre mes demandes</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="indent">
                            <h2 class="p0">Envoyer un colis</h2>
                            <h1 class="p0" style="color:steelblue;">Expédier vers</h1>
                           <div class="container border border-secondary" style="padding-top:2rem;padding-bottom:3rem;">
                            <form method="POST" action="colis1.php" enctype="multipart/form-data">
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="paysdest">Pays ou Terrritoire<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <select name="paysdest" id="paysdest" class="form-control" style="border-radius: 20px 20px; width: 15rem;height: 2.5rem;margin-bottom: 1rem; border: 1px solid #5c0a33;"required>
                                            <option>Tunisie</option>
                                            <option>France</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="adrdest">Adresse<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="adrdest" id="adrdest"  class="form-control" style="width :25rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                         <label for="villedest">Ville<span style="color:red">*</span></label>
                                     </div>
                                     <div class="col-md-auto">
                                         <input type="text" name="villedest" id="villedest" class="form-control" style="width :15rem;" required/>
                                     </div>
                                 </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="codedest">Code Postale<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="codedest" id="codedest" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="nomdest">Nom et Prénom du destinataire<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="nomdest" id="nomdest" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="emaildest">E-mail<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="emaildest" id="emaildest" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="phonedest">Téléphone<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="phonedest" id="phonedest" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2"></div>
                                    <div class=" col-md-auto">
                                        <input type="submit" name="submit" id="submit" style="width: 445px; height: 40px;" value="Continue">
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-bg">
                    <div class="wrapper">
                        <div class="col-1">
                            <div class="box first">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">01</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-1"><strong>Comment</strong>expedier</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php">>></a>
                                        <div class="extra-wrap">
                                            Vous avez déjà cherché un moyen d'envoyer des colis?<a class="link" target="_blank" href="colis.php">Cliquez ici</a>.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1">
                            <div class="box second">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">02</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-2"><strong>Comment</strong>transporter</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php"></a>
                                        <div class="extra-wrap">
                                            Vous voyagez souvent? Vous voulez rembourser vos frais de voyage?<a class="link" href="colis.php" target="_blank" rel="nofollow"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="box third">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">03</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-3"><strong>A propos</strong>de nous</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="contacts.php">>></a>
                                        <div class="extra-wrap">
                                            Découvrir notre concept, notre histoire, notre equipe.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <div class="row-top">
                <div class="row-padding">
                    <div class="wrapper">
                        <div class="col-1">
                            <h4>Adresse:</h4>
                            <dl class="address">
                                <dt><span>Pays:</span>Tunisie</dt>
                                <dd><span>Site web:</span>www.jwebi.com</dd>
                                <dd><span>Telephone:</span>+354 563-56-00</dd>
                                <dd><span>Email:</span><a href="#">hello@jwebi.com</a></dd>
                            </dl>
                        </div>
                        <div class="col-2">
                            <h4>Suivez-nous:</h4>
                            <ul class="list-services">
                                <li class="item-1"><a href="#">Facebook</a></li>
                                <li class="item-2"><a href="#">Twitter</a></li>
                                <li class="item-3"><a href="#">LinkedIn</a></li>
                            </ul>
                        </div>
                        <div class="col-3">
                            <h4>Pourquoi nous:</h4>
                            <ul class="list-1">
                                <li><a href="home.php">Accueil</a></li>
                                <li><a href="about.php">A propos</a></li>
                                <li><a href="colis.php">Expedier</a></li> 
                                <li><a href="transport.php">Transporter</a></li>
                            </ul>
                        </div>
                        <div class="col-4">
                            <div class="indent3">
                                <strong class="footer-logo">Jwebi.<strong>com</strong></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </div></div>