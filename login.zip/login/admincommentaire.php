<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="styleadministration.css">

<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
        <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script>
<title>Administration</title>
    <?php 
        $host="localhost";
        $user="root";
        $password="";
        $db="db";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        if ((isset($_GET['remove']))&&(!empty($_GET['remove']))){
            $remove =(int)$_GET['remove'];
            $req=$db->prepare("DELETE FROM user WHERE id=?");
            $req->execute(array($remove));
        }
        $members=$db->query('SELECT * fROM user ORDER BY id DESC');
    ?>
</head>
<body id="page5">
	<div class="bg">
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-20px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-30px;">
            
            <a href="../index.html"  style="color:black;"><i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong></a>
        </div>
    </div>
    <div class="container">
            <ul class="col-12 breadcrumb" style="margin-left:450px;">
                <li><a href="./admin.php">Gestion des clients</a></li>
                <li><a href="./adminvoyageur.php">Gestion des voyageurs</a></li>
                <li><a href="./admindemande.php">Gestion des demandes</a></li>
                <li><a href="./adminmessage.php">Gestion des messages</a></li>
                <li><a href="./admincommentaire.php">Gestion des commentaires</a></li>
			</ul>
    </div>
    <br>
    <table>
        <tr>
            <th style="color:white;">
                Id
            </th>
            <th style="color:white;">
                Nom du client/voyageur
            </th>
            <th style="color:white;">
                Les droits d'accés
            </th>
            <th style="color:white;">
                Email
            </th>
            <th style="color:white;">
                Supprimer
            </th>
        </tr>
        <?php while($member=$members->fetch()){ ?>
                <tr>
                    <td style="color:white;"><?php echo $member['id']?></td>
                    <td style="color:white;"><?php echo $member['fullname']?></td>
                    <td style="color:white;"><?php if ($member['type']==2){echo "client";} elseif($member['type']==1){echo "admin";} else {echo "voyageur";} ?></td>
                    <td style="color:white;"><?php echo $member['email']?></td>
                    <td style="color:white;">
                        <?php if($member['remove']==0) {?>
                        <a href="admin.php?remove=<?= $member['id']?>">Supprimer</a>
                        <?php } ?>
                    </td>
                </tr>
        <?php }?> 
    </table>
    </div>
</body>