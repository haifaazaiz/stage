<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/layout.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/styleColis.css">
<script type="text/javascript" src="../js/jquery-1.6.min.js"></script>
<script src="../js/cufon-yui.js" type="text/javascript"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script src="../js/cufon-replace.js" type="text/javascript"></script>
<script src="../js/Open_Sans_400.font.js" type="text/javascript"></script>
<script src="../js/Open_Sans_Light_300.font.js" type="text/javascript"></script> 
<script src="../js/Open_Sans_Semibold_600.font.js" type="text/javascript"></script>  
<script type="text/javascript" src="../js/tms-0.3.js"></script>
<script type="text/javascript" src="../js/tms_presets.js"></script> 
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script> 
<script src="../js/FF-cash.js" type="text/javascript"></script>
</head>
<body id="page5">
<?php
		session_start();
		$host="localhost";
		$user="root";
		$password="";
		$db="db";
		try{
			// connexion à la base de données db
			$db = new PDO('mysql:host=localhost;dbname=db;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
		}
		catch(Exception $e){
			// En cas d'erreur, on affiche un message et on quitte la page
			die('Erreur : '.$e->getMessage());
		}
		if (isset($_SESSION['id'])){
			$req=$db->prepare("SELECT * FROM user WHERE id=?");
			$req->execute(array($_SESSION['id']));
			$user=$req->fetch();
		}
        if((isset($_SESSION['id']))&&!empty($_POST['cin'])&&(!empty($_POST['passport']))&&!empty($_POST['moyen'])
        &&!empty($_POST['email'])&&!empty($_POST['phone']))
        {
            $idvoyageur=$_SESSION['id'];
            $cin=$_POST['cin'];
            $passport=$_POST['passport'];
            $moyen=$_POST['moyen'];
            $email=$_POST['email'];
            $phone=$_POST['phone'];

            $sql="INSERT INTO voyageur(idv, cin, passport, moyen, email, phone) VALUES (:idv, :cin, :passport, :moyen, :email, :phone)";      
            $req=$db->prepare($sql);
            $req->execute(array( 'idv' => $idvoyageur,'cin' => $cin,'passport' => $passport,'moyen' => $moyen,'email' => $email,'phone' => $phone,));
            
            echo " Your pub was successful !" ;
        } 
        if((isset($_SESSION['id']))&&isset($_FILES['fpassport'])&& !empty($_FILES['fpassport']['name'])){
            $taillemax = 2097152; //2 Mo
            $extensionsValides = array('jpg','jpeg','png','gif','pdf');
            if($_FILES["fpassport"]['size']<=$taillemax){
                $extensionsUpload = strtolower(substr(strrchr($_FILES['fpassport']['name'],'.'),1));//prendre juste l'exxtension
                if(in_array($extensionsUpload,$extensionsValides)){
                    $chemin="images/passport/".$_SESSION['id'].".".$extensionsUpload;
                    $result=move_uploaded_file($_FILES['fpassport']['tmp_name'],$chemin);
                    if($result){
                        $updateprofil=$db->prepare('UPDATE voyageur SET fichpassport= :pass WHERE idv= :idv');
                        $updateprofil->execute(array(
                            'pass'=>$_SESSION['id'].".".$extensionsUpload,
                            'idv'=>$_SESSION['id']));
                        /*$updatecomment=$db->prepare('UPDATE comment SET user_photo= :profile WHERE user_id= :id');
                        $updateprofil->execute(array(
                            'profile'=>$_SESSION['id'].".".$extensionsUpload,
                            'id'=>$_SESSION['id']));
                        $_SESSION['profile_photo']=$user_info['profile_photo'];*/
                    }
                    else{
                        $msg="Error during the importation of your file !";
                    }
                }
                else{
                    $msg="Make sure that the extension of your passport is jpg or jpeg or png or gif or pdf!";
                }
            }
            else{
                $msg="Your passport must not exceed the size of 2Mo !";
            }
        }
        if((isset($_SESSION['id']))&&isset($_FILES['visa'])&& !empty($_FILES['visa']['name'])){
            $taillemax = 2097152; //2 Mo
            $extensionsValides = array('jpg','jpeg','png','gif','pdf');
            if($_FILES["visa"]['size']<=$taillemax){
                $extensionsUpload = strtolower(substr(strrchr($_FILES['visa']['name'],'.'),1));//prendre juste l'exxtension
                if(in_array($extensionsUpload,$extensionsValides)){
                    $chemin="images/visa/".$_SESSION['id'].".".$extensionsUpload;
                    $result=move_uploaded_file($_FILES['visa']['tmp_name'],$chemin);
                    if($result){
                        $updateprofil=$db->prepare('UPDATE voyageur SET fichvisa= :visa WHERE idv= :idv');
                        $updateprofil->execute(array(
                            'visa'=>$_SESSION['id'].".".$extensionsUpload,
                            'idv'=>$_SESSION['id']));
                        /*$updatecomment=$db->prepare('UPDATE comment SET user_photo= :profile WHERE user_id= :id');
                        $updateprofil->execute(array(
                            'profile'=>$_SESSION['id'].".".$extensionsUpload,
                            'id'=>$_SESSION['id']));
                        $_SESSION['profile_photo']=$user_info['profile_photo'];*/
                    }
                    else{
                        $msg="Error during the importation of your file !";
                    }
                }
                else{
                    $msg="Make sure that the extension of your visa is jpg or jpeg or png or gif or pdf!";
                }
            }
            else{
                $msg="Your visa must not exceed the size of 2Mo !";
            }
        }
        if((isset($_SESSION['id']))&&isset($_FILES['billet'])&& !empty($_FILES['billet']['name'])){
            $taillemax = 2097152; //2 Mo
            $extensionsValides = array('jpg','jpeg','png','gif','pdf');
            if($_FILES["billet"]['size']<=$taillemax){
                $extensionsUpload = strtolower(substr(strrchr($_FILES['billet']['name'],'.'),1));//prendre juste l'exxtension
                if(in_array($extensionsUpload,$extensionsValides)){
                    $chemin="images/billet/".$_SESSION['id'].".".$extensionsUpload;
                    $result=move_uploaded_file($_FILES['billet']['tmp_name'],$chemin);
                    if($result){
                        $updateprofil=$db->prepare('UPDATE voyageur SET fichbillet= :billet WHERE idv= :idv');
                        $updateprofil->execute(array(
                            'billet'=>$_SESSION['id'].".".$extensionsUpload,
                            'idv'=>$_SESSION['id']));
                        /*$updatecomment=$db->prepare('UPDATE comment SET user_photo= :profile WHERE user_id= :id');
                        $updateprofil->execute(array(
                            'profile'=>$_SESSION['id'].".".$extensionsUpload,
                            'id'=>$_SESSION['id']));
                        $_SESSION['profile_photo']=$user_info['profile_photo'];*/
                    }
                    else{
                        $msg="Error during the importation of your file !";
                    }
                }
                else{
                    $msg="Make sure that the extension of your billet is jpg or jpeg or png or gif or pdf!";
                }
            }
            else{
                $msg="Your billet must not exceed the size of 2Mo !";
            }
        }
    ?>
<!-- header -->
	<div class="bg">
		<div class="main">
			<header>
				<div class="row-1">
					<div class="col-1">
						<h1>
							<a class="logo" href="index.php">Point.co</a>
							<strong class="slog">The most creative ideas</strong>
						</h1>
						<!--<form id="search-form" method="post" enctype="multipart/form-data">
							<fieldset>
								<div class="search-form">					
									<input type="text" name="search" value="Type Keyword Here" onBlur="if(this.value=='') this.value='Type Keyword Here'" onFocus="if(this.value =='Type Keyword Here' ) this.value=''" />
									<a href="#" onClick="document.getElementById('search-form').submit()">Search</a>									
								</div>
							</fieldset>
						</form>-->
					</div>
					<a class="btn" id="loginButton" role="button" style="float: right;" href="./login/Login_v1/index.html">
						<span class="fa fa-sign-in"></span>
                        <?php echo $_SESSION['fullname']; ?>
					</a>
				</div>
				<div class="row-2">
					<nav>
						<ul class="menu">
                            <li><a href="home.php">Accueil</a></li>
						  <li><a href="about.php">A propos</a></li>
						  <li><a href="transport.php" class="active" >Transport de colis</a></li>
						  <li><a href="colis.php" >Envoi de colis</a></li>
						  <li class="last-item"><a href="contacts.php">Centre d&apos;aide</a></li>
						</ul>
					</nav>
				</div>
			</header>
        <!-- content -->
        <section id="content">
            <div class="padding">
                <div class="wrapper margin-bot">
                    <div class="col-4">
                        <div class="block-news">
                            <h3 class="color-4 p2">Etapes</h3>
                            <ul class="list-2">
                                <li><a href="voyageur.php"><NOBR>Devenir voyageur</NOBR></a></li>
                                <li><a href="transport.php"><NOBR>Publier un trajet</NOBR></a></li>
                                <li><a href="#"><NOBR>Gérer les demandes</NOBR></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="indent">
                            <h2 class="p0">Devenir voyageur</h2>
                           <div class="container border border-secondary" style="padding-top:2rem;padding-bottom:3rem;">
                            <form method="POST" action="voyageur.php" enctype="multipart/form-data">
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="cin">Numéro de cin<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="cin" id="cin"  class="form-control" style="width :25rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="passport">Numéro de passport<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="passport" id="passport"  class="form-control" style="width :25rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="moyen">Moyen de transport<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="moyen" id="moyen"  class="form-control" style="width :25rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="fpassport">Scanner votre passport</label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="file" name="fpassport" id="fpassport"  class="form-control" style="margin-bottom: 1rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="visa">Scanner votre visa(Si le pays destination le nécessite)</label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="file" name="visa" id="visa"  class="form-control" style="margin-bottom: 1rem;"/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="billet">Scanner votre billet d'avion</label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="file" name="billet" id="billet"  class="form-control" style="margin-bottom: 1rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="email">E-mail<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="email" id="email" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2">
                                        <label for="phone">Téléphone<span style="color:red">*</span></label>
                                    </div>
                                    <div class="col-md-auto">
                                        <input type="text" name="phone" id="phone" class="form-control" style="width :15rem;" required/>
                                    </div>
                                </div>
                                <div class="form-group row text-center">
                                    <div class="col col-lg-2"></div>
                                    <div class=" col-md-auto">
                                        <input type="submit" name="submit" id="submit" style="width: 25rem; height: 40px;" value="Envoyer la demande">
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-bg">
                    <div class="wrapper">
                        <div class="col-1">
                            <div class="box first">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">01</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-1"><strong>Comment</strong>expedier</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php">>></a>
                                        <div class="extra-wrap">
                                            Vous avez déjà cherché un moyen d'envoyer des colis?<a class="link" target="_blank" href="colis.php">Cliquez ici</a>.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1">
                            <div class="box second">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">02</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-2"><strong>Comment</strong>transporter</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="colis.php"></a>
                                        <div class="extra-wrap">
                                            Vous voyagez souvent? Vous voulez rembourser vos frais de voyage?<a class="link" href="colis.php" target="_blank" rel="nofollow"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="box third">
                                <div class="pad">
                                    <div class="wrapper indent-bot">
                                        <strong class="numb img-indent2">03</strong>
                                        <div class="extra-wrap">
                                            <h3 class="color-3"><strong>A propos</strong>de nous</h3>
                                        </div>
                                    </div>
                                    <div class="wrapper">
                                        <a class="button img-indent-r" href="contacts.php">>></a>
                                        <div class="extra-wrap">
                                            Découvrir notre concept, notre histoire, notre equipe.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <div class="row-top">
                <div class="row-padding">
                    <div class="wrapper">
                        <div class="col-1">
                            <h4>Adresse:</h4>
                            <dl class="address">
                                <dt><span>Pays:</span>Tunisie</dt>
                                <dd><span>Site web:</span>www.jwebi.com</dd>
                                <dd><span>Telephone:</span>+354 563-56-00</dd>
                                <dd><span>Email:</span><a href="#">hello@jwebi.com</a></dd>
                            </dl>
                        </div>
                        <div class="col-2">
                            <h4>Suivez-nous:</h4>
                            <ul class="list-services">
                                <li class="item-1"><a href="#">Facebook</a></li>
                                <li class="item-2"><a href="#">Twitter</a></li>
                                <li class="item-3"><a href="#">LinkedIn</a></li>
                            </ul>
                        </div>
                        <div class="col-3">
                            <h4>Pourquoi nous:</h4>
                            <ul class="list-1">
                                <li><a href="home.php">Accueil</a></li>
                                <li><a href="about.php">A propos</a></li>
                                <li><a href="colis.php">Expedier</a></li> 
                                <li><a href="transport.php">Transporter</a></li>
                            </ul>
                        </div>
                        <div class="col-4">
                            <div class="indent3">
                                <strong class="footer-logo">Jwebi.<strong>com</strong></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </div></div>